# Legacy Archive

These files are **NOT imported** and **NOT supported**.

They are kept for historical reference only.

Do NOT copy code from these files into the main codebase.

## Archived Files

- `repqms_Proto1_reference.py.py` - Original prototype reference code
- `repqms_shipstation_sync.py.py` - Original ShipStation sync reference code

These files contain patterns and approaches that were used in earlier versions but have been replaced with the modular architecture in `app/eqms/modules/`.
